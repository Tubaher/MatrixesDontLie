
//================================================================================================================

int CargarImagenes(void)
{
    int i, aux;
	float numero;
    FILE *in_file; 
    
    //FILE *in_file;
    
    printf("%d", change_img);
    
    if (change_img < 10)
    {
        aux=0;
        if ((in_file = fopen ("shakira_1.dat", "rt")) == NULL)
            aux=1;
        else
        {
            fseek(in_file, 0, SEEK_SET);
        
                for (i=0; i<10000; i++)
                {
                    fscanf(in_file, "%f", &numero);
                    copy[i][1]=numero;
                }
        }
        fclose(in_file);
    }
    
    if (change_img >= 10 && change_img < 20)
    {
        aux=0;
        if ((in_file = fopen ("shakira_2.dat", "rt")) == NULL)
            aux=1;
        else
        {
            fseek(in_file, 0, SEEK_SET);
        
                for (i=0; i<10000; i++)
                {
                    fscanf(in_file, "%f", &numero);
                    copy[i][1]=numero;
                }
        }
        fclose(in_file);
    }
    
    if (change_img >= 20 && change_img < 30)
    {
        aux=0;
        if ((in_file = fopen ("shakira_3.dat", "rt")) == NULL)
            aux=1;
        else
        {
            fseek(in_file, 0, SEEK_SET);
        
                for (i=0; i<10000; i++)
                {
                    fscanf(in_file, "%f", &numero);
                    copy[i][1]=numero;
                }
        }
        fclose(in_file);
    }
    
    /*
    if (change_img >= 30 && change_img < 40)
    {
        aux=0;
        if ((in_file = fopen ("bin_shakira.dat", "rt")) == NULL)
            aux=1;
        else
        {
            fseek(in_file, 0, SEEK_SET);
        
                for (i=0; i<10000; i++)
                {
                    fscanf(in_file, "%f", &numero);
                    copy[i][1]=numero;
                }
        }
        fclose(in_file);
    }*/
    
    return(aux);
}
//-----------------------------------------------
/*int SalvarPesos(void)
{
	int k, i, aux;
	float numero;
	FILE *out_file;
	aux=0;
	if ((out_file = fopen ("S_GRID_HID.DAT", "wt")) == NULL)
		aux=1;
	else
	{
		fseek(out_file, 0, SEEK_SET);
		for (k=0; k<N_HID; k++)
			for (i=0; i<N_IN; i++)
			{
				numero=c_escondida.pesos[k][i];
				fprintf(out_file, "%f %c", numero,'\n');
			}
		  }
	if ((out_file = fopen ("S_GRID_OUT.DAT", "wt")) == NULL)
		aux=aux+2;
	else
	{
		fseek(out_file, 0, SEEK_SET);
		for (k=0; k<N_SAL; k++)
			for (i=0; i<N_HID; i++)
			{
              numero=c_salida.pesos[k][i];
              fprintf(out_file, "%f %c", numero, '\n');
			}
    }
	fclose(out_file);
    moveto(20,20);
    setcolor(WHITE);
    settextstyle(3, HORIZ_DIR, 1);
    outtext("Pesos Salvados ");
	return(aux);
}
*/
//-----------------------------------------------
